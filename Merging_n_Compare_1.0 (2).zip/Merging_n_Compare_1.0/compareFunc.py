def getBold(meanDiffSd):
    if meanDiffSd == 1.0 or meanDiffSd >= 0.81:
        boldLevel = 5
    elif meanDiffSd <= 0.8 and meanDiffSd >= 0.61:
        boldLevel = 4
    elif meanDiffSd <= 0.6 and meanDiffSd >= 0.41:
        boldLevel = 3
    elif meanDiffSd <= 0.4 and meanDiffSd >= 0.21:
        boldLevel = 2
    elif meanDiffSd <= 0.2 and meanDiffSd > 0:
        boldLevel = 1
    else:
        boldLevel = 0
    return boldLevel