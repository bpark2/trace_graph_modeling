#Merging of DepGraphs
#Verson 1.0
#author: Brendan Park
import os
import argparse
import networkx as nx
from graphviz import Source

parser = argparse.ArgumentParser(description='Merge graphs')
parser.add_argument('file', help='file to read')
parser.add_argument('--limit',
                    dest='limit',
                    type=int,
                    default=0,
                    help='number of execution to read')

args = parser.parse_args()

def getPath(executions, indexTo):
    """
        executions: list of execution dicts with data
        indexTo: index to look at
        Updates "executions" array with path
        
        Recursively retrieves the path of a node and
        updates the list of executions
    """
    if executions[indexTo]["parent"] == 0:
        executions[indexTo]["checked"] = True
        return
    else:
        if executions[indexTo]["checked"] == False:
            for y in range(len(executions)):
                if executions[y]["id"] == executions[indexTo]["parent"]:
                    getPath(executions, y)
                    executions[indexTo]["path"] = executions[indexTo]["path"] +'-'+ executions[y]["path"]
                    executions[indexTo]["checked"] = True
        else:
            getPath(executions, indexTo+1)
            

with open(args.file, "r") as f:
    executions = []
    ids = {}
    pExecs = []
    execNum = 0
    g = list()
    # skip two first lines
    next(f)
    next(f)
    for l in f.readlines():
        if "execution" not in l:
            item, name, size, parent = l.split(",")
            executions.append({
                "id": int(item[6:]),
                "name": str(name[7:]).lower().replace('-',' '),
                "size": int(size[6:]),
                "parent": int(parent[9:]),
                "path":str(name[7:]).lower().replace('-',' '),
                "checked":False
            })
            ids[str(name[7:]).lower().replace('-',' ')] = int(item[6:])
        else:
            pExecs.append(executions)
            executions = []
    pExecs.append(executions)
    for x in range(len(pExecs)):#list of lists
        for y in range(len(pExecs[x])):#list of dicts
                getPath(pExecs[x],y)

    sizes = {}#sysname:size
    counts = {}#sysname: count
    min = {}#sysname: min (size)
    max = {}#sysname: max(size)
    #merging the counts, sizes, min, max of each unique node via their path
    for x in range(len(pExecs)):#list of list of dicts with execution details
        for y in pExecs[x]:#list of execution details
            if y['path'] not in counts.keys():
                counts[y['path']] = 1
            else:
                counts[y['path']] += 1
            if y['path'] not in min.keys():
                min[y['path']] = y['size']
            elif y['size'] < min[y['path']]:
                min[y['path']] = y['size']
            if y['path'] not in max.keys():
                max[y['path']] = y['size']
            elif y['size'] > max[y['path']]:
                max[y['path']] = y['size']
            if y['path'] not in sizes.keys():
                sizes[y['path']] = y['size']
            else:
                sizes[y['path']] += y['size']
    
    w = open("".join(args.file.split(".")[:-1])+"Merged.txt","w+")
    w.write("------------------ \n")
    w.write(args.file + " Merged: \n")
    #printing out data for future comparison
    for x in counts.keys():
        if len(str(x).split('-')) > 1:
            w.write("item: "+str(ids[str(x).split('-')[0]])+", name: "+(str(x).split('-')[0])+", size: "+str(sizes[x])+", parent: "+str(ids[str(x).split('-')[1]])+", count: "+str(counts[x])+", max: "+str(max[x])+", min: "+str(min[x])+", path:"+x+"\n")
        else:
            w.write("item: "+str(ids[str(x).split('-')[0]])+", name: "+(str(x).split('-')[0])+", size: "+str(sizes[x])+", parent: 0, count: "+str(counts[x])+", max: "+str(max[x])+", min: "+str(min[x])+", path:"+x+"\n")
    w.close()
    #make digraph
    dot = nx.DiGraph()
    nodes = []
    #creating digraph edges (they automatically generate nodes)
    for x in range(len(pExecs)):
        for y in pExecs[x]:
            #root has parent 0
            if y["parent"] != 0:
            #need to find parent for size
                for z in range(len(pExecs)):
                    for v in pExecs[z]:
                        if v["id"] == y["parent"]:
                            p = sizes[y["path"]]/sizes[v["path"]]#this is right
                            dot.add_edge(((v["path"].split('-')[0].replace(':',' ')),('('+str(sizes[v["path"]])+')'),('Max '+str(max[v['path']])),('Min '+str(min[v['path']])),('Count '+str(counts[v['path']]))),
                                        ((y["path"].split('-')[0].replace(':',' ')),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y['path']])),('Min '+str(min[y['path']])),('Count '+str(counts[y['path']]))),
                                        label="{:.0%}".format(p))
                            if ((y["path"].split('-')[0].replace(':',' ')),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y['path']])),('Min '+str(min[y['path']])),('Count '+str(counts[y['path']]))) in nodes:
                                nodes.remove(((y["path"].split('-')[0].replace(':',' ')),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y['path']])),('Min '+str(min[y['path']])),('Count '+str(counts[y['path']]))))
                            if ((v["path"].split('-')[0].replace(':',' ')),('('+str(sizes[v["path"]])+')'),("Max "+str(max[v['path']])),('Min '+str(min[v['path']])),('Count '+str(counts[v['path']]))) in nodes:
                                nodes.remove(((v["path"].split('-')[0].replace(':',' ')),('('+str(sizes[v["path"]])+')'),('Max '+str(max[v['path']])),('Min '+str(min[v['path']])),('Count '+str(counts[v['path']]))))
                            break
            else:
                path = "merged/{}_merged".format("".join(args.file.split(".")[:-1]))
    for n in nodes:
        if n in dot:
            dot.remove_node(n)
    for n in dot.nodes():
        if dot.edges(n) == None:
            dot.remove_node(n)
    path = "output/{}_merged".format("".join(args.file.split(".")[:-1]))
    nx.drawing.nx_pydot.write_dot(dot, path)
    dot = Source.from_file(path, engine='dot')
    dot.render(path, cleanup=True)