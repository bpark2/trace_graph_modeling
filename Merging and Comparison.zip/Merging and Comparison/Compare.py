#Comparing of Merged DepGraphs
#Verson 1.0
#author: Brendan Park
import os
import argparse
import numpy as np
import networkx as nx
from compareFunc import *
from graphviz import Source

parser = argparse.ArgumentParser(description='Merge graphs')
parser.add_argument('file1', help='file to read')
parser.add_argument('file2', help='file to read')

args = parser.parse_args()
f1 = open(args.file1, "r")
f2 = open(args.file2, "r")
executions1 = []
executions2 = []

next(f1)
next(f1)
#reading in both sets of merged data
for l in f1.readlines():
    item, name, size, parent, count, max, min, path = l.split(",")
    executions1.append({
        "id": int(item[6:]),
        "name": str(name[7:]).lower().replace(':',' '),
        "size": int(size[6:]),
        "parent": int(parent[9:]),
        "count":int(count[7:]),
        "max":max[6:],
        "min":min[6:],
        "path":path.replace(':',' ')[6:-1],
        "in":1
    })
next(f2)
next(f2)
for l in f2.readlines():
    item, name, size, parent, count, max, min, path = l.split(",")
    executions2.append({
        "id": int(item[6:]),
        "name": str(name[7:]).lower().replace(':',' '),
        "size": int(size[6:]),
        "parent": int(parent[9:]),
        "count":int(count[7:]),
        "max":max[6:],
        "min":min[6:],
        "path":path.replace(':',' ')[6:-1],
        "in":2
    })
means1 = {}
sds1 = {}
means2 = {}
leftSds = 0
totCount = {}
diffMeans = {}
leftCounts = []
meanDiffSd = {}
boldness = {}
sizes = {}
counts = {}
min = {}
max = {}
#merging their values for comparison graph printout
for x in executions1:
    if x["path"] not in counts.keys():
        counts[x["path"]] = 1
    else:
        counts[x["path"]] += 1
    if x["path"] not in sizes.keys():
        sizes[x["path"]] = x["size"]
    else:
        sizes[x["path"]] += x["size"]
    if x['path'] not in min.keys():
        min[x['path']] = x['size']
    elif x['size'] < min[x['path']]:
        min[x['path']] = x['size']
    if x['path'] not in max.keys():
        max[x['path']] = x['size']
    elif x['size'] > max[x['path']]:
        max[x['path']] = x['size']
        
for x in executions2: 
    if x["path"] not in counts.keys():
        counts[x["path"]] = 1
    else:
        counts[x["path"]] += 1
    if x["path"] not in sizes.keys():
        sizes[x["path"]] = x["size"]
    else:
        sizes[x["path"]] += x["size"]
    if x['path'] not in min.keys():
        min[x['path']] = x['size']
    elif x['size'] < min[x['path']]:
        min[x['path']] = x['size']
    if x['path'] not in max.keys():
        max[x['path']] = x['size']
    elif x['size'] > max[x['path']]:
        max[x['path']] = x['size']
print("sizes")
print(sizes)
#get total count of each occurance of a unique node
for x in executions1:
    if x["path"] in totCount.keys():
        totCount[x["path"]] = totCount[x["path"]] + x["count"]
    else:
        totCount[x["path"]] = x["count"]
for x in executions2:
    if x["path"] in totCount.keys():
        totCount[x["path"]] = totCount[x["path"]] + x["count"]
    else:
        totCount[x["path"]] = x["count"]
print("Total Count")
print(totCount)
#left difference of means
for x in executions1:
    means1[x["path"]] = x["count"]/totCount[x["path"]]
#left standard deviation
for x in executions1:
    leftCounts.append(x["count"])
#print(leftCounts)
leftSds = np.std(leftCounts)
print("Left Standard Deviation")
print(leftSds)

#right difference of means
for x in executions2:
    means2[x["path"]] = x["count"]/totCount[x["path"]]
for x in means1:
    if x in means2:
        diffMeans[x] = means2[x] - means1[x]
#issue here, if it doesn't appear in both it doesn't get a difference of means does this affect the future?
#no diffMeans = no meanDiffSd = no boldness = 

print("Left Means")
print(means1)
print("Right Means")
print(means2)
print("Diff Means")
print(diffMeans)

for x in diffMeans.keys():
    if leftSds != None:
        meanDiffSd[x] = diffMeans[x]/leftSds
    else:
        meanDiffSd[x] = float('inf')
print("Mean Diff Sd")
print(meanDiffSd)
for x in meanDiffSd.keys():
   boldness[x] = getBold(meanDiffSd[x])
print("Boldness")
print(boldness)
#differentiating between those that appear in both sets of data and those that dont
for x in executions1:
    for y in executions2:
        if x["path"] in y["path"]:
            x["in"] = 3
for x in executions2:
    for y in executions1:
        if x["path"] in y["path"]:
            x["in"] = 3
# create directed graph
dot = nx.DiGraph()
# list of nodes
nodes = []
path = ""
# create edges (the node must exist)
for x in executions1:
    # root has parent 0
    if x["parent"] != 0:
        # need to find its parent to get the size
        for y in executions1:
            if y["id"] == x["parent"]:
                p = sizes[x["path"]] / sizes[y["path"]]
                if x["in"] == 3:
                    if x["path"] in boldness.keys():#if it appeared in both then edge=solid, assign colour for level of difference
                        if boldness[x["path"]] == 5:
                            dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                        ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="red3", style="solid")
                        elif boldness[x["path"]] == 4: 
                            dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                        ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="red", style="solid")
                        elif boldness[x["path"]] == 3:
                            dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                        ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="yellow", style="solid")
                        elif boldness[x["path"]] == 2:
                            dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                        ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="lightgreen", style="solid")
                        elif boldness[x["path"]] == 1:
                            dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                        ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="green", style="solid")
                        elif boldness[x["path"]] == 0:#no difference between 1 and 2
                            dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                        ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="grey", style="solid")
                    else:#it appears only in the first/left graph so assign a black dotted edge
                        dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="black", style="dotted")
                elif x["in"] == 1:
                    dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="black", style="dotted")
                #, width = boldness[x["path"]]
                if x["path"].split('-')[0] in nodes:
                    nodes.remove(x["path"].split('-')[0])
                if y["path"].split('-')[0] in nodes:
                    nodes.remove(y["path"].split('-')[0])
                break
    else:
        path = "output/{}_{}_compared".format("".join(args.file1.split(".")[:-1]), "".join(args.file2.split(".")[:-1]))
# remove nodes that don't have an edge
#for n in nodes:
#    dot.remove_node(n)

for x in executions2:
    # root has parent 0
    if x["parent"] != 0:
        # need to find its parent to get the size
        for y in executions2:
            if y["id"] == x["parent"]:
                p = sizes[x["path"]] / sizes[y["path"]]
                if x["in"] == 3:
                    if x["path"] in boldness.keys():#if it appeared in both then edge=solid, assign colour for level of difference
                        if boldness[x["path"]] == 5:
                            dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                        ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="red3", style="solid")
                        elif boldness[x["path"]] == 4: 
                            dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                        ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="red", style="solid")
                        elif boldness[x["path"]] == 3:
                            dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                        ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="yellow", style="solid")
                        elif boldness[x["path"]] == 2:
                            dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                        ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="lightgreen", style="solid")
                        elif boldness[x["path"]] == 1:
                            dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                        ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="green", style="solid")
                        elif boldness[x["path"]] == 0:
                            dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                        ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="grey", style="solid")
                    else:#it appears only in the first/left graph so assign a black dotted edge
                        dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="black", style="dashed")
                elif x["in"] == 2:
                    dot.add_edge(((y["path"].split('-')[0]),('('+str(sizes[y["path"]])+')'),('Max '+str(max[y["path"]])),('Min '+str(min[y["path"]])),('Count '+str(min[y["path"]]))),
                                ((x["path"].split('-')[0]),('('+str(sizes[x["path"]])+')'),('Max '+str(max[x["path"]])),('Min '+str(min[x["path"]])),('Count '+str(min[x["path"]]))), color="black", style="dashed")
                if str(x["path"].split('-')[0]) in nodes:
                    nodes.remove(str(x["path"].split('-')[0]))
                if str(y["path"].split('-')[0]) in nodes:
                    nodes.remove(str(y["path"].split('-')[0]))
                break
    else:
        path = "output/{}_{}_compared".format("".join(args.file1.split(".")[:-1]), "".join(args.file2.split(".")[:-1]))
# remove nodes that don't have an edge
for n in nodes:
    dot.remove_node(n)
    
print("Executions1")
print(executions1)
print("Executions2")
print(executions2)

nx.drawing.nx_pydot.write_dot(dot, path)
dot = Source.from_file(path, engine='dot')
dot.render(path, cleanup=True)