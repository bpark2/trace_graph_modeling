import os
import argparse
import networkx as nx
from graphviz import Source

parser = argparse.ArgumentParser(description='Create graphs')
parser.add_argument('file', help='file to read')
parser.add_argument('--limit',
                    dest='limit',
                    type=int,
                    default=0,
                    help='number of execution to read')
parser.add_argument('--threshold',
                    dest='threshold',
                    type=float,
                    default=0,
                    help='minimum percentage of time to create an edge')
args = parser.parse_args()

folder = "graphs_{}".format("".join(args.file.split(".")[:-1]))
if not os.path.exists(folder):
    os.mkdir(folder)

with open(args.file, "r") as f:
    execution = []
    # skip two first lines
    next(f)
    next(f)
    # counter
    n_execution = 0
    for l in f.readlines():
        if "execution" not in l:
            item, name, size, parent = l.split(",")
            execution.append({
                "id": int(item[6:]),
                "name": name[7:],
                "size": int(size[6:]),
                "parent": int(parent[8:-1])
            })
        # end of the execution, create the graph
        else:
            # create directed graph
            dot = nx.DiGraph()
            # list of nodes
            nodes = []
            # create nodes
            for x in execution:
                dot.add_node(str(x["id"]),
                             label="{} ({})".format(x["name"], x["size"]))
                nodes.append(str(x["id"]))
            # initialize path to save the graph
            path = ""
            # create edges (the node must exists)
            for x in execution:
                # root has parent 0
                if x["parent"] != 0:
                    # need to find its parent to get the size
                    for y in execution:
                        if y["id"] == x["parent"]:
                            p = x["size"] / y["size"]
                            if p >= args.threshold:
                                dot.add_edge(str(y["id"]),
                                             str(x["id"]),
                                             label="{:.0%}".format(p))
                                if str(x["id"]) in nodes:
                                    nodes.remove(str(x["id"]))
                                if str(y["id"]) in nodes:
                                    nodes.remove(str(y["id"]))
                            break
                else:
                    path = "{}/graph_root_node_{}_{}_{}".format(
                        folder, x["name"], x["size"], n_execution)
            # remove nodes that don't have an edge
            for n in nodes:
                dot.remove_node(n)
            nx.drawing.nx_pydot.write_dot(dot, path)
            dot = Source.from_file(path, engine='dot')
            dot.render(path, cleanup=True)
            execution = []
            n_execution += 1
            if n_execution % 10 == 0:
                print("\rGraph created: {:6d}".format(n_execution), end="")
            if args.limit and n_execution > args.limit:
                break
